package com.fithe.common.dao;

import com.fithe.member.vo.MemberVO;

public interface ChabunDAO {
	public MemberVO getChabun();
}
