package com.fithe.common.service;

import com.fithe.member.vo.MemberVO;

public interface ChabunService {
	public MemberVO getChabun();
}
